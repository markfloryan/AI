package ttr.model.trainCards;

public class TrainCard {

	private TrainCardColor color;
	
	public TrainCard(TrainCardColor color){
		this.color = color;
	}
	
	public TrainCardColor getColor(){return this.color;}
}
