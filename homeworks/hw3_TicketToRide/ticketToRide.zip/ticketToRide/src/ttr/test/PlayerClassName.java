package ttr.test;

/**
 * The names of the classes the students have submitted. Used by FullCourseTester.java
 * to play every pair of student submissions against one another.
 * */
public enum PlayerClassName {

	StupidPlayer;

}
